package com.pillu.jarvis

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

class JarvisNotifications : NotificationListenerService() {
    class Item(val title: String, val text: String, val sbn: StatusBarNotification)

    companion object {
        private val apps = setOf("com.whatsapp", "com.whatsapp.w4b", "com.google.android.apps.messaging",
            "com.samsung.android.messaging", "com.android.mms", "com.instagram.android", "org.telegram.messenger")
        val items = CopyOnWriteArrayList<Item>()

        fun read(reply: (String) -> Unit) {
            if (items.isEmpty()) { reply("You have no new messages, or notification access is off."); return }
            reply(items.take(3).joinToString(". ") { "From ${it.title}: ${it.text}" })
        }

        fun replyLast(ctx: Context, text: String, reply: (String) -> Unit) {
            for (it in items) {
                val act = it.sbn.notification.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true } ?: continue
                val ri = act.remoteInputs
                val intent = Intent()
                val b = Bundle().apply { putCharSequence(ri[0].resultKey, text) }
                RemoteInput.addResultsToIntent(ri, intent, b)
                try { act.actionIntent.send(ctx, 0, intent); reply("Replied to ${it.title}") }
                catch (e: Exception) { reply("I could not send the reply") }
                return
            }
            reply("There is no message I can reply to")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in apps) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        items.add(0, Item(title, text, sbn))
        while (items.size > 10) items.removeAt(items.size - 1)
    }
}
