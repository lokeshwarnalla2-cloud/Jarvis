package com.pillu.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Starts Jarvis again after the phone restarts (only if you pressed START before)
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && c.getSharedPreferences("jarvis", 0).getBoolean("auto", false))
            try { c.startForegroundService(Intent(c, JarvisService::class.java)) } catch (_: Exception) {}
    }
}
