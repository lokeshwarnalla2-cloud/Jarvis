package com.pillu.jarvis

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {
    companion object { var instance: JarvisAccessibilityService? = null }

    // Waits for WhatsApp to open the chat, then taps the Send button.
    fun clickSend(attempts: Int = 10) {
        Handler(Looper.getMainLooper()).postDelayed({
            val root = rootInActiveWindow
            var node: AccessibilityNodeInfo? = root?.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")?.firstOrNull()
            if (node == null) node = root?.findAccessibilityNodeInfosByText("Send")
                ?.firstOrNull { it.packageName == "com.whatsapp" && (it.isClickable || it.parent?.isClickable == true) }
            if (node != null) {
                (if (node.isClickable) node else node.parent)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else if (attempts > 0) clickSend(attempts - 1)
        }, 1000)
    }

    // Opens Quick Settings and taps a tile (Wi-Fi, Hotspot, Bluetooth, Mobile data) if it is not already in the wanted state.
    fun toggleTile(labels: List<String>, wantOn: Boolean, done: (Boolean) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        tryTile(labels, wantOn, 8, done)
    }

    private fun tryTile(labels: List<String>, wantOn: Boolean, attempts: Int, done: (Boolean) -> Unit) {
        Handler(Looper.getMainLooper()).postDelayed({
            val root = rootInActiveWindow
            var node: AccessibilityNodeInfo? = null
            for (l in labels) {
                node = root?.findAccessibilityNodeInfosByText(l)?.firstOrNull { it.isClickable || it.parent?.isClickable == true }
                if (node != null) break
            }
            if (node == null) {
                if (attempts > 0) tryTile(labels, wantOn, attempts - 1, done)
                else { performGlobalAction(GLOBAL_ACTION_BACK); done(false) }
                return@postDelayed
            }
            val st = ((if (Build.VERSION.SDK_INT >= 30) node.stateDescription?.toString() else null)
                ?: node.contentDescription?.toString() ?: "").lowercase()
            val isOff = Regex("\\boff\\b").containsMatchIn(st)
            val isOn = node.isChecked || (Regex("\\bon\\b").containsMatchIn(st) && !isOff)
            if ((wantOn && !isOn) || (!wantOn && !isOff)) {
                (if (node.isClickable) node else node.parent)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            Handler(Looper.getMainLooper()).postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 700)
            done(true)
        }, 800)
    }

    // Tap anything on screen that has this text or label
    fun clickText(text: String): Boolean {
        val node = rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull() ?: return false
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    // Type into the focused text box (or the first text box on screen)
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: find(root) { it.isEditable } ?: return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun scroll(forward: Boolean): Boolean {
        val n = rootInActiveWindow?.let { r -> find(r) { it.isScrollable } } ?: return false
        return n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun find(n: AccessibilityNodeInfo, ok: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (ok(n)) return n
        for (i in 0 until n.childCount) { val c = n.getChild(i) ?: continue; find(c, ok)?.let { return it } }
        return null
    }

    override fun onServiceConnected() {
        instance = this
        // Revive Jarvis after a reboot or if Android stopped it
        val auto = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("auto", false)
        if (auto && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED)
            try { startForegroundService(android.content.Intent(this, JarvisService::class.java)) } catch (_: Exception) {}
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }
}
