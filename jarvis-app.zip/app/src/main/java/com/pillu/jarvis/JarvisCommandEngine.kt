package com.pillu.jarvis

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.os.Build
import android.provider.CalendarContract
import android.telecom.TelecomManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import android.os.Handler
import android.os.Looper
import android.media.AudioManager
import android.provider.MediaStore
import android.view.KeyEvent
import android.hardware.camera2.CameraManager
import android.telephony.SmsManager

object JarvisCommandEngine {

    fun handle(ctx: Context, raw: String, ai: Boolean = true, reply: (String) -> Unit) {
        val clean = raw.trim().replace(Regex("^(hey\\s+)?jarvis[\\s,.]*", RegexOption.IGNORE_CASE), "")
        val t = clean.lowercase()
        val a11y = JarvisAccessibilityService.instance
        when {
            t.isEmpty() -> reply("Yes, I am listening")

            isToggle(t) -> toggle(ctx, t, reply)

            msgRegex.find(t) != null -> sendMessage(ctx, clean, t, reply)

            t.contains("timer") && Regex("\\d").containsMatchIn(t) -> setTimer(ctx, t, reply)
            t.startsWith("remind ") -> remind(ctx, clean, reply)
            t.startsWith("calendar ") -> calendar(ctx, clean, reply)
            t.startsWith("navigate to ") || t.startsWith("directions to ") -> navigate(ctx, t.substringAfter(" to "), reply)
            t == "what time is it" || t == "what's the time" || t == "time" ->
                reply("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            t == "what's the date" || t == "what is the date" || t == "what day is it" || t == "date" ->
                reply("Today is " + SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()))
            t == "take a photo" || t == "take a picture" || t == "take a selfie" || t == "selfie" -> camera(ctx, t, reply)
            t == "answer call" || t == "answer the call" || t == "pick up" || t == "answer" -> callControl(ctx, true, reply)
            t == "reject call" || t == "reject the call" || t == "hang up" || t == "end call" || t == "decline" -> callControl(ctx, false, reply)
            t == "read messages" || t == "read my messages" || t == "read notifications" -> JarvisNotifications.read(reply)
            t.startsWith("reply ") -> JarvisNotifications.replyLast(ctx, clean.substringAfter(" "), reply)

            chainRegex.find(t) != null -> {
                val c = chainRegex.find(t)!!
                val second = clean.substring(c.groups[2]!!.range.first)
                if (second.lowercase().startsWith("play ") && !second.lowercase().contains(" on "))
                    handle(ctx, "$second on ${c.groupValues[1]}", reply = reply)
                else {
                    handle(ctx, "open ${c.groupValues[1]}") {}
                    Handler(Looper.getMainLooper()).postDelayed({ handle(ctx, second, reply = reply) }, 3000)
                }
            }

            t == "pause" || t == "pause music" || t == "stop music" -> { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE); reply("Paused") }
            t == "resume" || t == "resume music" || t == "play" || t == "play music" -> { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY); reply("Playing") }
            t == "next" || t == "next song" || t == "skip" -> { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT); reply("Next song") }
            t == "previous" || t == "previous song" || t == "last song" -> { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS); reply("Previous song") }
            t == "volume up" || t == "louder" -> { volume(ctx, AudioManager.ADJUST_RAISE); reply("Louder") }
            t == "volume down" || t == "quieter" -> { volume(ctx, AudioManager.ADJUST_LOWER); reply("Quieter") }
            t == "mute" -> { volume(ctx, AudioManager.ADJUST_MUTE); reply("Muted") }
            t.startsWith("play ") -> play(ctx, t, reply)

            // control whatever app is on screen
            t == "press enter" || t == "enter" -> uiAction(reply) { if (it.pressEnter()) "Done" else "I could not press enter" }
            t.startsWith("click ") || t.startsWith("tap ") || t.startsWith("press ") ->
                uiAction(reply) { if (it.clickText(t.substringAfter(" "))) "Clicked" else "I could not find that on the screen" }
            t.startsWith("type ") || t.startsWith("write ") ->
                uiAction(reply) { if (it.typeText(clean.substringAfter(" "))) "Typed" else "I could not find a text box" }
            t == "scroll down" -> uiAction(reply) { it.scroll(true); "Scrolling down" }
            t == "scroll up" -> uiAction(reply) { it.scroll(false); "Scrolling up" }

            t.startsWith("open ") -> openApp(ctx, t.removePrefix("open ").trim(), reply)

            t.startsWith("call ") -> {
                val who = t.removePrefix("call ").removePrefix("my ").trim()
                val num = if (who.any { it.isLetter() }) findContact(ctx, who) else who.filter { it.isDigit() || it == '+' }
                if (num.isNullOrEmpty()) reply("I could not find $who in your contacts")
                else {
                    try { launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:$num"))) }
                    catch (e: SecurityException) { launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))) }
                    reply("Calling $who")
                }
            }

            Regex("^set alarm \\d{1,2}[: ]?\\d{0,2}$").matches(t) -> {
                val m = Regex("(\\d{1,2})[: ]?(\\d{2})?").find(t)
                if (m == null) reply("Tell me the time, like: set alarm 7 30")
                else {
                    val h = m.groupValues[1].toInt()
                    val min = m.groupValues[2].ifEmpty { "0" }.toInt()
                    launch(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    reply("Alarm set for $h:${min.toString().padStart(2, '0')}")
                }
            }

            t.startsWith("search ") || t.startsWith("google ") -> {
                val q = t.substringAfter(" ")
                launch(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                reply("Searching for $q")
            }

            t == "go home" || t == "home" -> act(a11y, AccessibilityService.GLOBAL_ACTION_HOME, "Going home", reply)
            t == "go back" || t == "back" -> act(a11y, AccessibilityService.GLOBAL_ACTION_BACK, "Going back", reply)
            t.contains("recent") -> act(a11y, AccessibilityService.GLOBAL_ACTION_RECENTS, "Showing recent apps", reply)
            t.contains("notification") -> act(a11y, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Opening notifications", reply)
            t.contains("screenshot") -> act(a11y, AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Taking screenshot", reply)

            else -> if (!ai) reply("Sorry, I cannot do that yet") else AiBrain.ask(clean) { out ->
                // The AI turns any wording into a command we know, or just answers
                Handler(Looper.getMainLooper()).post {
                    val c = Regex("(?im)^CMD:\\s*(.+)$").find(out)
                    if (c != null) handle(ctx, c.groupValues[1].trim(), false, reply) else reply(out)
                }
            }
        }
    }

    private fun act(s: JarvisAccessibilityService?, action: Int, ok: String, reply: (String) -> Unit) {
        if (s == null) reply("Please turn on Jarvis in Accessibility settings first.")
        else { s.performGlobalAction(action); reply(ok) }
    }

    private fun openApp(ctx: Context, name: String, reply: (String) -> Unit) {
        val pm = ctx.packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(name)
        }
        val intent = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (intent == null) reply("I could not find $name")
        else { launch(ctx, intent); reply("Opening $name") }
    }

    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (JarvisAccessibilityService.instance ?: ctx).startActivity(i) // accessibility may start apps from background
    }

    // Also tries without spaces, because the phone may hear "dead pool" for contact "Deadpool"
    private fun findContact(ctx: Context, name: String): String? =
        findContactRaw(ctx, name) ?: findContactRaw(ctx, name.replace(" ", ""))

    private fun findContactRaw(ctx: Context, name: String): String? = try {
        ctx.contentResolver.query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }

    private val msgRegex = Regex("^(?:open \\w+,? (?:and |then )?)?(?:go to chats?,? (?:and |then )?)?(?:send (?:a )?(?:(?:whatsapp|sms|text) )?(?:(?:message|msg)(?: to)?|to)|send (?:a )?(?:whatsapp|sms|text)|message|whatsapp|text|sms) (.+)$")

    // "send message to my brother I am busy" -> finds contact "brother", sends "I am busy"
    private fun sendMessage(ctx: Context, clean: String, t: String, reply: (String) -> Unit) {
        val m = msgRegex.find(t)!!
        var rest = clean.substring(m.groups[1]!!.range.first).trim()
        if (rest.lowercase().startsWith("my ")) rest = rest.substring(3)
        val viaSms = t.contains("sms") || t.startsWith("text") || t.contains("send text")

        var name: String? = null; var num: String? = null; var msg = ""
        val d = Regex("^(.+?)\\s+(?:saying|say|that says|that|telling him|telling her|with message)\\s+(.+)$", RegexOption.IGNORE_CASE).find(rest)
        if (d != null) {
            name = d.groupValues[1]; msg = d.groupValues[2]; num = findContact(ctx, name)
        } else {
            val w = rest.split(" ")
            for (n in minOf(3, w.size - 1) downTo 1) {
                val c = findContact(ctx, w.take(n).joinToString(" "))
                if (c != null) { name = w.take(n).joinToString(" "); num = c; msg = w.drop(n).joinToString(" "); break }
            }
        }
        if (num == null || msg.isBlank()) { reply("Tell me who and what, like: send message to brother I am busy"); return }

        if (viaSms) {
            try {
                val sms = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                          else @Suppress("DEPRECATION") SmsManager.getDefault()
                sms.sendTextMessage(num, null, msg, null, null)
                reply("Message sent to $name")
            } catch (e: Exception) { reply("I could not send the SMS. Please allow SMS permission.") }
        } else {
            try {
                val url = "https://wa.me/${waNumber(ctx, num)}?text=${Uri.encode(msg)}"
                launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp"))
                val a11y = JarvisAccessibilityService.instance
                if (a11y != null) { a11y.clickSend(); reply("Sending WhatsApp to $name") }
                else reply("I opened the chat. Turn on phone control so I can press send.")
            } catch (e: Exception) { reply("WhatsApp is not installed") }
        }
    }

    // WhatsApp needs the country code. Uses the one saved in the app if the contact has none.
    private fun waNumber(ctx: Context, num: String): String {
        val d = num.filter { it.isDigit() }
        if (num.trim().startsWith("+")) return d
        val cc = ctx.getSharedPreferences("jarvis", 0).getString("cc", "") ?: ""
        return if (cc.isNotEmpty() && d.length <= 10) cc + d.trimStart('0') else d
    }

    private fun isToggle(t: String) =
        Regex("^(turn|switch|enable|disable)\\b").containsMatchIn(t) &&
        Regex("wifi|wi-fi|hotspot|bluetooth|mobile data|internet|flashlight|torch").containsMatchIn(t)

    // "turn off hotspot", "turn on wifi", "turn off bluetooth", "turn on flashlight"
    private fun toggle(ctx: Context, t: String, reply: (String) -> Unit) {
        val wantOn = !(t.contains(" off") || t.startsWith("disable"))
        val state = if (wantOn) "on" else "off"
        if (t.contains("flashlight") || t.contains("torch")) {
            try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], wantOn); reply("Flashlight $state")
            } catch (e: Exception) { reply("I could not control the flashlight") }
            return
        }
        val (name, labels) = when {
            t.contains("hotspot") -> "Hotspot" to listOf("Hotspot", "Tethering")
            t.contains("bluetooth") -> "Bluetooth" to listOf("Bluetooth")
            t.contains("mobile data") -> "Mobile data" to listOf("Mobile data", "Internet")
            t.contains("wifi") || t.contains("wi-fi") -> "Wi-Fi" to listOf("Wi-Fi", "Internet")
            else -> "Internet" to listOf("Wi-Fi", "Mobile data", "Internet")
        }
        val a = JarvisAccessibilityService.instance
        if (a == null) reply("Please turn on phone control first")
        else a.toggleTile(labels, wantOn) { ok ->
            reply(if (ok) "$name turned $state" else "I could not find $name in quick settings")
        }
    }

    private val chainRegex = Regex("^open (.+?),? (?:and|then) ((?:play|click|tap|press|scroll|type|write|pause|volume) .*)$")

    private fun uiAction(reply: (String) -> Unit, f: (JarvisAccessibilityService) -> String) {
        val a = JarvisAccessibilityService.instance
        reply(if (a == null) "Please turn on phone control first" else f(a))
    }

    private fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(ctx: Context, dir: Int) {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    // "play believer", "play believer on spotify", "play lofi on youtube"
    private fun play(ctx: Context, t: String, reply: (String) -> Unit) {
        var q = t.removePrefix("play ").trim(); var app = ""
        Regex("^(.+) on (.+)$").find(q)?.let { q = it.groupValues[1]; app = it.groupValues[2] }
        if (app.contains("youtube") && !app.contains("music")) {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(q)}"))
                .setPackage("com.google.android.youtube")
            try { launch(ctx, i); reply("Searching $q on YouTube") } catch (e: Exception) { reply("YouTube is not installed") }
            return
        }
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, q)
        if (app.contains("spotify")) i.setPackage("com.spotify.music")
        else if (app.contains("music")) i.setPackage("com.google.android.apps.youtube.music")
        try { launch(ctx, i); reply("Playing $q") } catch (e: Exception) { reply("I could not find a music app") }
    }

    private fun setTimer(ctx: Context, t: String, reply: (String) -> Unit) {
        var secs = 0
        Regex("(\\d+)\\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)").findAll(t).forEach {
            val n = it.groupValues[1].toInt()
            val u = it.groupValues[2]
            secs += if (u.startsWith("h")) n * 3600 else if (u.startsWith("m")) n * 60 else n
        }
        if (secs == 0) { reply("For how long?"); return }
        launch(ctx, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        reply("Timer set")
    }

    // "remind 17:30 buy milk" (rings at that time with your note)
    private fun remind(ctx: Context, clean: String, reply: (String) -> Unit) {
        val m = Regex("^remind (\\d{1,2}):(\\d{2}) (.+)$", RegexOption.IGNORE_CASE).find(clean)
        if (m == null) { reply("Tell me the time and what to remind you"); return }
        launch(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, m.groupValues[1].toInt()).putExtra(AlarmClock.EXTRA_MINUTES, m.groupValues[2].toInt())
            .putExtra(AlarmClock.EXTRA_MESSAGE, m.groupValues[3]).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        reply("Reminder set")
    }

    // "calendar 2026-10-08 15:00 Meeting with Sam"
    private fun calendar(ctx: Context, clean: String, reply: (String) -> Unit) {
        val m = Regex("^calendar (\\d{4})-(\\d{2})-(\\d{2}) (\\d{1,2}):(\\d{2}) (.+)$", RegexOption.IGNORE_CASE).find(clean)
        if (m == null) { reply("I could not understand the event"); return }
        val g = m.groupValues
        val c = Calendar.getInstance().apply { set(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), g[4].toInt(), g[5].toInt(), 0) }
        launch(ctx, Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, c.timeInMillis)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, c.timeInMillis + 3600000)
            .putExtra(CalendarContract.Events.TITLE, g[6]))
        Handler(Looper.getMainLooper()).postDelayed({ JarvisAccessibilityService.instance?.clickText("Save") }, 2500)
        reply("Adding ${g[6]} to your calendar")
    }

    private fun navigate(ctx: Context, place: String, reply: (String) -> Unit) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(place)}"))
        try { launch(ctx, i.setPackage("com.google.android.apps.maps")) } catch (e: Exception) { launch(ctx, Intent(i).setPackage(null)) }
        reply("Navigating to $place")
    }

    private fun camera(ctx: Context, t: String, reply: (String) -> Unit) {
        val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        if (t.contains("selfie")) i.putExtra("android.intent.extras.CAMERA_FACING", 1).putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
        launch(ctx, i)
        Handler(Looper.getMainLooper()).postDelayed({
            val a = JarvisAccessibilityService.instance
            if (a != null) listOf("Shutter", "Take picture", "Take photo", "Capture").any { a.clickText(it) }
        }, 3000)
        reply("Taking a photo")
    }

    private fun callControl(ctx: Context, answer: Boolean, reply: (String) -> Unit) {
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (answer) tm.acceptRingingCall() else tm.endCall()
            reply(if (answer) "Answering" else "Done")
        } catch (e: SecurityException) { reply("Please allow phone permission in the app") }
    }
}
