package com.pillu.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        AiBrain.apiKey = prefs.getString("key", "") ?: ""

        status = TextView(this).apply { text = "Setup: 1) phone control  2) keys  3) Start"; textSize = 16f }
        val claudeKey = EditText(this).apply { hint = "Claude API key"; setText(AiBrain.apiKey); setSingleLine() }
        val picoKey = EditText(this).apply { hint = "Picovoice AccessKey"; setText(prefs.getString("pico", "")); setSingleLine() }
        val ccBox = EditText(this).apply { hint = "Your country code, e.g. 91"; setText(prefs.getString("cc", "")); setSingleLine() }
        val langBox = EditText(this).apply { hint = "Voice language, e.g. en-IN or hi-IN (optional)"; setText(prefs.getString("lang", "")); setSingleLine() }
        fun btn(label: String, click: () -> Unit) = Button(this).apply { text = label; setOnClickListener { click() } }

        val save = btn("Save keys") {
            AiBrain.apiKey = claudeKey.text.toString().trim()
            prefs.edit().putString("key", AiBrain.apiKey).putString("pico", picoKey.text.toString().trim()).putString("cc", ccBox.text.toString().trim()).putString("lang", langBox.text.toString().trim()).apply()
            status.text = "Keys saved"
        }
        val a11y = btn("1. Turn on phone control") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        val notif = btn("2. Allow reading messages (notification access)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        val start = btn("3. START Jarvis") { startJarvis() }
        val stop = btn("Stop Jarvis") { getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("auto", false).apply(); stopService(Intent(this, JarvisService::class.java)); status.text = "Jarvis stopped" }
        val battery = btn("Keep Jarvis alive (battery)") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            listOf(status, a11y, notif, claudeKey, picoKey, ccBox, langBox, save, start, stop, battery).forEach { addView(it) }
        })
    }

    private fun startJarvis() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("auto", true).apply()
        startForegroundService(Intent(this, JarvisService::class.java))
        status.text = "Jarvis is running. Say \"Jarvis\" then your command."
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startJarvis()
        else status.text = "Microphone permission is needed"
    }
}
