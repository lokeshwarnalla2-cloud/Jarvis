package com.pillu.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaPlayer
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

// Always-on listener: waits for "Jarvis", then listens for ONE command.
class JarvisService : Service(), TextToSpeech.OnInitListener {
    private var porcupine: PorcupineManager? = null
    private lateinit var tts: TextToSpeech
    private lateinit var recognizer: SpeechRecognizer
    private val main = Handler(Looper.getMainLooper())
    private var followUps = 0 // how many follow-up commands in a row (no wake word needed)

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" then your command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        tts = TextToSpeech(this, this)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { resume() }
            override fun onDone(id: String?) {
                if (followUps < 5) { followUps++; main.postDelayed({ listen() }, 400) } else resume()
            }
        })
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text == null) resume()
                else if (Regex("^(?:jarvis )?(?:stop|cancel|bye|that's all|thanks|thank you)$").matches(text.lowercase().trim())) { followUps = 99; speak("Okay boss") }
                else JarvisCommandEngine.handle(this@JarvisService, text) { speak(it) }
            }
            override fun onError(e: Int) { followUps = 0; resume() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        setupWakeWord()
    }

    private fun setupWakeWord() {
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("pico", "") ?: ""
        try {
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .build(this) { main.post { onWake() } }
            porcupine?.start()
        } catch (e: Exception) {
            followUps = 99; speak("Wake word error. Check your Picovoice key. ${e.message}")
        }
    }

    private fun onWake() {
        porcupine?.stop() // free the microphone
        followUps = 0
        val mp = MediaPlayer.create(this, R.raw.jarvis_voice) // your own Jarvis voice clip
        if (mp == null) { listen(); return }
        mp.setOnCompletionListener { it.release(); listen() }
        mp.start()
    }

    private fun listen() {
        recognizer.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            getSharedPreferences("jarvis", MODE_PRIVATE).getString("lang", "")?.takeIf { it.isNotEmpty() }?.let { putExtra(RecognizerIntent.EXTRA_LANGUAGE, it) }
        })
    }

    private fun resume() = main.post { try { porcupine?.start() } catch (_: Exception) {} }
    private fun speak(t: String) = main.post { tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") }
    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) {
            val l = getSharedPreferences("jarvis", MODE_PRIVATE).getString("lang", "") ?: ""
            tts.language = if (l.isNotEmpty()) Locale.forLanguageTag(l) else Locale.getDefault()
        }
    }

    override fun onDestroy() {
        try { porcupine?.stop(); porcupine?.delete() } catch (_: Exception) {}
        recognizer.destroy(); tts.shutdown()
        super.onDestroy()
    }
}
