HANDS-FREE JARVIS (say "Jarvis, call my brother")
BUILD: same as before (Android Studio > copy these files over your project > Build APK).
Check app/build.gradle.kts has BOTH appcompat and porcupine-android lines in dependencies.

FIRST-TIME SETUP ON THE PHONE
1. Get a FREE AccessKey at console.picovoice.ai (this is the "Jarvis" wake word engine).
2. Get a Claude API key at console.anthropic.com (for answering questions).
3. Open the app: tap "1. Turn on phone control" and enable Pillu JARVIS.
4. Paste both keys, tap "Save keys".
5. Tap "Keep Jarvis alive (battery)" and allow it, so Android does not stop it.
6. Tap "3. START Jarvis" and allow microphone, contacts, phone permissions.
7. Close the app. Say "Jarvis" -> you hear a beep -> say "call my brother".

IMPORTANT: "call my brother" works if the contact in your phone is saved as "Brother".
Also try: "open YouTube", "set alarm 7 30", "search best pizza", "go home", any question.

YOUR VOICE: the clip is app/src/main/res/raw/jarvis_voice.mp3. Jarvis plays it when he hears "Jarvis".
To change it, replace that file (keep the name jarvis_voice.mp3, lowercase).

SENDING MESSAGES BY VOICE
- Put your country code (like 91) in the app and tap Save keys. Then turn phone control OFF and ON again once (new permission).
- Say: "Jarvis" -> "Yes boss" -> "send message to my brother I am busy"  (sends on WhatsApp)
- Say: "send SMS to brother I am busy"  (sends a normal text message)
- Also works: "open WhatsApp and send message to mom I will call you later"
- Contact must be saved in your phone with that name (Brother, Mom, ...).
- Instagram: opening it works ("open Instagram"), but sending Instagram DMs by voice is not supported.

PHONE SWITCHES BY VOICE
Say: "Jarvis" -> "Yes boss" -> "turn off hotspot" / "turn on wifi" / "turn off bluetooth" / "turn off mobile data" / "turn on flashlight"
Jarvis opens Quick Settings, taps the button, and closes it. Needs phone control ON.

NO INTERNET: the "Jarvis" wake word works offline. To also understand commands offline, download the offline language:
Phone Settings > search "Google voice typing" (or "Speech services") > Offline speech recognition > download your language.

APPS BY VOICE
- "Jarvis" -> "Yes boss" -> "open Spotify and play Believer"   (also: "play Believer on YouTube", "play lofi")
- "pause", "resume", "next song", "previous song", "volume up", "volume down", "mute"
- Inside any open app: "click search", "type lofi beats", "press enter", "scroll down", "scroll up", "click Reels", "go back"
- After each command Jarvis keeps listening for your NEXT command (no need to say "Jarvis" again). Say "stop" or "thanks" to end, or stay quiet.
- Example: "open Instagram" ... "click search" ... "type football" ... "press enter" ... "scroll down" ... "thanks"

=== SIRI-LIKE UPGRADE ===
NEW IN THIS VERSION
- Understands ANY wording (the AI turns it into an action): "ring Deadpool", "wake me at 6 tomorrow", "text mom I'm late".
- Remembers the last few things you said ("and what about tomorrow?"). Weather, news, scores via web search.
- Timers, reminders, calendar events, navigation ("navigate to the airport"), time/date, photo/selfie.
- Answer / reject calls ("answer the call", "hang up"). Read and reply to messages ("read my messages", "reply I'll call you later").
- Starts again after phone restart. Hindi/other languages: type e.g. hi-IN in the language box.
SETUP (once): rebuild APK, install, then
 1. Tap "1. Turn on phone control" (turn OFF and ON again).
 2. Tap "2. Allow reading messages" and enable Pillu JARVIS.
 3. Save keys/language, tap START, allow ALL permission popups (phone, SMS, contacts, microphone).
 4. Do not raise targetSdk above 34 in build.gradle.kts.

=== BUILD THE APK ON GITHUB (no Android Studio) ===
1. github.com > New repository (name: pillu-jarvis, Private is fine).
2. Unzip jarvis-app.zip on a computer. In the repository: Add file > Upload files, drag EVERYTHING from inside the unzipped folder (including the hidden ".github" folder). Commit.
3. Open the Actions tab > "Build APK" > wait about 5 minutes for the green tick.
4. Click the finished run > Artifacts > "Jarvis-APK" > download, unzip, install app-debug.apk on your phone.
If the run turns red, open it and send me the error text.
